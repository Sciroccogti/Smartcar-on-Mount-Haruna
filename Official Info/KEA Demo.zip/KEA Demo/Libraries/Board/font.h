#ifndef _font_h
#define _font_h

#include "common.h"

extern const unsigned char asc2_1206[95][12];
extern unsigned char image[];
extern unsigned char hanzi[];
extern const unsigned char asc2_1608[95][16];
extern const uint8 ASCII_8x16[][16];
extern const uint8 F6x8[][6];
extern unsigned char show[];
extern unsigned char test[];
extern unsigned char gImage_123[105];
//extern unsigned char gImage_baidu[2700];
extern unsigned char gImage_zhuoqing[10240];

#endif
